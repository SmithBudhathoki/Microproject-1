document.getElementById('loadBtn').addEventListener('click', async () => {
    const response = await fetch('/api/items');
    const items = await response.json();
  
    const outputDiv = document.getElementById('output');
    outputDiv.innerHTML = '';
  
    items.forEach(item => {
      const div = document.createElement('div');
      div.className = 'card';
      div.innerHTML = `<h3>${item.name}</h3><p>Price: $${item.price}</p>`;
      outputDiv.appendChild(div);
    });
  });
  