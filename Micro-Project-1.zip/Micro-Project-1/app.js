const express = require('express');
const path = require('path');
const fs = require('fs');
const data = require('./data/items.json');

const app = express();
const PORT = 3000;

app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/items', (req, res) => {
  res.json(data);
});

app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
