# Microproject#1 - Express Static Website with API

## Features
- Express.js server
- API route `/api/items`
- Static HTML website (4 pages)
- Demo page with button to fetch JSON data using Async/Await
- Styled with CSS

## Setup Instructions
1. Clone the repo
2. Run `npm install`
3. Start with `npm run dev` (or `npm start`)
4. Visit: `http://localhost:3000/demo.html`

## Author
Your Name
